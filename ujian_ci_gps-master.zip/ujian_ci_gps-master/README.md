"# ujian_ci_gps" 
